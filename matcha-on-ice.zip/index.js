require('./dist/index.cjs');
